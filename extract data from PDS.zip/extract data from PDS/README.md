# Files to download LIBS data from MSL and Mars 2020 missions from NASA's PDS
## by Cai Ytsma (cai@caiconsulting.co.uk)

These programs run automatically, but before running you should install the required packages (requirements.txt). These scripts build upon existing data folders and files, so you need to copy the contents of the initial_files folders to wherever you will be storing the data so the datasets can be intiated. Those files just contain one sol of data.

If the connection breaks during the procedure, it will automatically store and update what data it has pulled so far and then continue.

Feel free to edit as needed!